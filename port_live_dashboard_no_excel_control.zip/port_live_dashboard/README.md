# Port Operation Live Dashboard

This package turns the existing `input data 1.22.xlsm` dashboard into a browser-based live monitor.

## Architecture

Port Office PC → Excel → `update_dashboard.py` → GitHub `data.json` → GitHub Pages → Main Office Chrome Kiosk.

The updater reads the cached values from the **Port Operation Dashboard** sheet. If Microsoft Excel is installed, it first asks desktop Excel to recalculate and save the workbook, so formulas such as Loaded, Balance, Progress, Remarks and Activity Time are current.

## 1. Create the GitHub website

Create a new GitHub repository, e.g. `port-live-dashboard`. Upload the **contents of the `site` folder** to the repository root.

Enable GitHub Pages from the repository's Pages settings using branch `main` and folder `/ (root)`.

After Pages is active, the website address will normally be:

`https://YOUR_GITHUB_USERNAME.github.io/port-live-dashboard/`

## 2. Configure the Port Office updater

Copy `updater/config.example.json` to `updater/config.json` and edit:

- `excel_path`: full path to your real `.xlsm` file.
- `github.owner`: your GitHub username or organization.
- `github.repo`: repository name.
- `github.branch`: normally `main`.
- `github.path`: keep `data.json` if the website file is at repository root.
- `github.token`: a GitHub fine-grained personal access token with **Contents: Read and write** permission for this repository.

Keep `config.json` private. It is already listed in `.gitignore`.

## 3. Install and run

On the Port Office Windows PC, install Python 3.11+ if needed, then double-click `updater/run_updater.bat`.

The updater checks the workbook every 10 seconds. It only uploads to GitHub when operational data changes, so it does not create unnecessary commits.

For a silent background run, create a Windows shortcut that runs:

`wscript.exe "C:\PortDashboard\updater\run_hidden.vbs"`

Put that shortcut in the Windows Startup folder if desired.

## 4. Main Office kiosk

Open the GitHub Pages URL in Chrome. For fullscreen kiosk mode, create a shortcut with:

`chrome.exe --kiosk "https://YOUR_GITHUB_USERNAME.github.io/port-live-dashboard/"`

The web page checks for new `data.json` every 10 seconds and displays Philippine local time.

## Important

GitHub Pages is near-real-time, not guaranteed sub-second streaming. In normal use, expect updates after the Port Office Excel save/recalculation plus the GitHub Pages/CDN propagation time. For a truly instant LAN/WAN WebSocket system, use a dedicated server instead of GitHub Pages.


## Important Excel behavior
The updater does NOT open, recalculate, save, or control Excel. It only reads the last saved workbook data. Excel can remain open and editable normally. Save the workbook after entering changes so the updater can publish the latest saved values.
