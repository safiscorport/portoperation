Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c cd /d """ & Replace(WScript.ScriptFullName,"run_hidden.vbs","") & """ && python update_dashboard.py", 0, False
