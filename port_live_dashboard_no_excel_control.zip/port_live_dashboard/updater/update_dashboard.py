import base64, hashlib, json, os, sys, time
from datetime import datetime, date, time as dtime
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT=Path(__file__).resolve().parent
CFG=ROOT/'config.json'
DEFAULT_WB=Path(r'C:\PortDashboard\input data 1.22.xlsm')
SITE_DATA=ROOT.parent/'site'/'data.json'


def load_cfg():
    if not CFG.exists():
        raise SystemExit('Missing config.json. Copy config.example.json to config.json and fill in the GitHub settings.')
    c=json.loads(CFG.read_text(encoding='utf-8'))
    c.setdefault('excel_path', str(DEFAULT_WB))
    c.setdefault('refresh_seconds', 10)
    c.setdefault('github', {})
    return c


def excel_recalculate(path):
    """Disabled intentionally. The updater never opens, recalculates, saves, or controls Excel.
    It only reads the last saved workbook data, so Excel remains available for normal editing.
    """
    return False, 'Excel control disabled — reading the last saved workbook only'


def copy_workbook_for_read(path):
    """Copy the workbook to a temporary file before reading, minimizing interaction with an open Excel file."""
    import shutil, tempfile
    temp_dir=Path(tempfile.gettempdir()) / 'port_live_dashboard'
    temp_dir.mkdir(parents=True, exist_ok=True)
    temp_path=temp_dir / 'dashboard_source.xlsm'
    shutil.copy2(path, temp_path)
    return temp_path


def clean(v):
    if v is None: return None
    if isinstance(v,str):
        s=v.strip()
        return s if s else None
    return v


def activity(v):
    if isinstance(v, datetime):
        return f'{v.hour:02d}:{v.minute:02d}'
    if isinstance(v, dtime):
        return f'{v.hour:02d}:{v.minute:02d}'
    if isinstance(v, (int,float)):
        mins=max(0,int(round(v*24*60)))
        return f'{mins//60:02d}:{mins%60:02d}'
    return clean(v) or '00:00'


def read_dashboard(path):
    from openpyxl import load_workbook
    temp_path=copy_workbook_for_read(path)
    wb=load_workbook(temp_path, data_only=True, read_only=True, keep_vba=False)
    ws=wb['Port Operation Dashboard']
    def v(r,c): return ws.cell(r,c).value
    berths=[]
    for r in range(4,15):
        berths.append({
            'berth':clean(v(r,2)) or f'Berth {r-3}', 'vessel':clean(v(r,3)) or 'VACANT',
            'voyage':clean(v(r,4)) or 0, 'booking':v(r,5) or 0, 'dispatch':v(r,6) or 0,
            'loaded':v(r,7) or 0, 'balance':v(r,8) or 0, 'progress':v(r,9) or 0,
            'stockpile':v(r,10) or 0, 'time':activity(v(r,11)), 'remarks':clean(v(r,12)) or '',
            'equipment':clean(v(r,14)) or '0', 'activity_time':activity(v(r,15))
        })
    def n(r,c):
        x=v(r,c)
        return x if isinstance(x,(int,float)) else 0
    total={'booking':n(15,5),'dispatch':n(15,6),'loaded':n(15,7),'balance':n(15,8),'progress':n(15,9),'stockpile':n(15,10)}
    trucking=[]
    for r in range(23,31):
        h=clean(v(r,2))
        if h: trucking.append({'hauler':h,'august':n(r,3),'september':n(r,4),'daily':n(r,5)})
    monthly=[]
    for r in range(24,30):
        monthly.append({'month':clean(v(r,7)) or clean(v(r,10)) or '', 'y2025':n(r,8), 'y2026':n(r,9)})
    # Add Oct-Dec if present on the right-hand monthly table.
    for r in range(27,30):
        monthly.append({'month':clean(v(r,10)) or '', 'y2025':n(r,11), 'y2026':n(r,12)})
    daily=[]
    for r in range(23,26):
        daily.append({'shift':clean(v(r,13)) or '', 'qty':n(r,14)})
    status={'stevedores':n(32,8),'cranes':n(5,10),'forklifts':n(5,11),'supervisor':clean(v(32,4)) or '', 'checker':clean(v(33,4)) or '', 'pmc':clean(v(34,4)) or ''}
    alpha=[]
    for r in range(17,20):
        alpha.append({'berth':clean(v(r,2)) or '', 'vessel':clean(v(r,3)) or 'VACANT', 'materials':clean(v(r,5)) or '', 'remarks':clean(v(r,12)) or ''})
    foreign={'berth':clean(v(21,2)) or 'Jetty','vessel':clean(v(21,3)) or 'VACANT','remarks':clean(v(21,12)) or ''}
    data={'updated_at':datetime.now().astimezone().isoformat(),'berths':berths,'total':total,'trucking':trucking,'monthly':monthly,'daily_production':daily,'status':status,'alpha':alpha,'foreign':foreign}
    wb.close()
    return data


def canonical(data):
    return json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'))


def github_request(method,url,token,payload=None):
    body=None
    headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'port-live-dashboard-updater'}
    if payload is not None:
        body=json.dumps(payload).encode(); headers['Content-Type']='application/json'
    req=Request(url,data=body,headers=headers,method=method)
    with urlopen(req,timeout=30) as r:
        raw=r.read()
        return json.loads(raw.decode() or '{}')


def github_upload(data_text,cfg):
    gh=cfg['github']; token=gh.get('token') or os.getenv('GITHUB_TOKEN')
    owner=gh.get('owner'); repo=gh.get('repo'); branch=gh.get('branch','main'); path=gh.get('path','data.json')
    if not token or not owner or not repo: return False,'GitHub settings are incomplete'
    api=f'https://api.github.com/repos/{owner}/{repo}/contents/{path}'
    try:
        old=None
        try: old=github_request('GET',api+f'?ref={branch}',token)
        except HTTPError as e:
            if e.code!=404: raise
        sha=old.get('sha') if old else None
        if old and base64.b64decode(old.get('content','')).decode('utf-8',errors='replace').strip()==data_text.strip():
            return False,'No data change'
        payload={'message':gh.get('commit_message','Live dashboard update'),'content':base64.b64encode(data_text.encode()).decode(),'branch':branch}
        if sha: payload['sha']=sha
        github_request('PUT',api,token,payload)
        return True,'Uploaded to GitHub'
    except Exception as e:
        return False,f'GitHub upload failed: {e}'


def once(cfg):
    wb=Path(cfg['excel_path']).expanduser()
    if not wb.exists(): raise SystemExit(f'Excel file not found: {wb}')
    ok,msg=excel_recalculate(wb); print(msg)
    data=read_dashboard(wb)
    text=json.dumps(data,ensure_ascii=False,indent=2)
    old=SITE_DATA.read_text(encoding='utf-8') if SITE_DATA.exists() else ''
    # Compare excluding timestamp so the site only changes when operational data changes.
    try: old_obj=json.loads(old); old_obj.pop('updated_at',None)
    except Exception: old_obj=None
    cmp_obj=dict(data); cmp_obj.pop('updated_at',None)
    changed=canonical(old_obj or {})!=canonical(cmp_obj)
    if changed or not SITE_DATA.exists():
        SITE_DATA.write_text(text+'\n',encoding='utf-8')
        print('Local data.json updated.')
        uploaded,umsg=github_upload(text+'\n',cfg)
        print(umsg)
    else:
        print('No operational data change; GitHub upload skipped.')


def main():
    cfg=load_cfg(); interval=int(cfg.get('refresh_seconds',10))
    print('PORT LIVE DASHBOARD UPDATER — running every',interval,'seconds')
    while True:
        try: once(cfg)
        except KeyboardInterrupt: print('\nStopped.'); return
        except Exception as e: print('ERROR:',e)
        time.sleep(interval)

if __name__=='__main__': main()
